<style>b
    a:link, a:visited, a:active {

        color: white;

    }
</style>



<nav style="background-color: #DFA708" class="navbar  sticky-top  flex-md-nowrap p-0">
    <a  style=" font-weight: 900;" class="navbar-brand col-sm-3 col-md-2 mr-0" href="dashboard.php">   HighSchool
    </a>
    <ul class="navbar-nav px-3">
        <li class="nav-item text-nowrap">
            <a  class="nav-link" style=" font-weight: 900;"  href="../controller/deconnection.php"> <img src="../img/close.png"> Deconnection</a>
        </li>
    </ul>
</nav>


<div class="container-fluid">
    <div class="row">
        <nav class="col-md-2 d-none d-md-block bg-light sidebar">
            <div class="sidebar-sticky">
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link active" href="dashboard.php">
                            <img src="../img/dashboard.png">
                            Dashboard
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="contenuform.php">
                            <img src="../img/file.png">
                            Creation Contenu
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contenu.php">
                            <img src="../img/list.png">
                            Liste des Contenus
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="listeUser.php">
                            <img src="../img/user.png">
                            Liste des Utilisateurs
                        </a>
                    </li>

                </ul>



            </div>
        </nav>



